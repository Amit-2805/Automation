import os
import re
import shutil
import subprocess
from pathlib import Path


def fun_for_taking_input():
    File_name = input("Enter The File Name for generating reports : ")
    File_name_upper = File_name.upper()
    
    return File_name,File_name_upper


def fun_for_creating_folder_structure(File_name):
    base_name = "_VCAST_UT_Results"
    dir_name = File_name + base_name
    html_tst_dir = os.path.join(dir_name,"Html&Tst's" )
    unit_tst_dir = os.path.join(html_tst_dir, "Unit_Tst's")
    os.makedirs(html_tst_dir, exist_ok=True)
    os.makedirs(unit_tst_dir, exist_ok=True)
    
    return html_tst_dir, unit_tst_dir
    
    
    
    
def fun_for_generating_compound_tst(full_script_local):
    with open(full_script_local, errors='ignore') as file_compound:
        for File_lines_compound in file_compound.readlines():
            if File_lines_compound.startswith("-- COMPOUND TESTS"):
                return True
    return False
    
    
    
def fun_for_generating_reports(File_name,File_name_upper,html_tst_dir,unit_tst_dir):
    tst_extension_for_file = ".tst"
    os.system(r"%VECTORCAST_DIR%\clicast.exe -e {} TEST Script Create {}{}".format(File_name_upper, File_name_upper, tst_extension_for_file))
    os.system('move "{}.tst" "{}"'.format(File_name_upper, html_tst_dir))
    reports = ["Management", "Actual", "Full"]
    for report in reports:
        os.system(r'%VECTORCAST_DIR%\clicast.exe -lc -e {} Reports Custom {} {}_{}_Report.html'.format(File_name_upper,report,File_name,report))
    Full_script = os.path.join(html_tst_dir, File_name_upper + tst_extension_for_file)

    with open(Full_script, errors='ignore') as file:
        for File_lines in file.readlines():
            if re.match(r'\s*-- Subprogram:', File_lines):
                file_name = File_lines.split(":")[-1].strip() 
                os.system(r"%VECTORCAST_DIR%\clicast.exe -e {} -u {} -s {} Test Script Create {}.tst".format(File_name_upper,File_name,file_name, file_name))
                os.system('move "{}.tst" "{}"'.format(file_name,unit_tst_dir))

    os.rename(File_name+"_Actual_Report.html",File_name+"_Execution_Results_Report.html")
    os.rename(File_name+"_Management_Report.html",File_name+"_Testcase_Management_Report.html")
    
    Report_for_html_report = ["_Full_Report.html", "_Execution_Results_Report.html", "_Testcase_Management_Report.html"]
    for report_html in Report_for_html_report:
        os.system('move "{}""{}" "{}"'.format(File_name,report_html,html_tst_dir))

    flag = fun_for_generating_compound_tst(Full_script)
    if flag:
        os.system(r'%VECTORCAST_DIR%\clicast.exe -e {} -u {} -s "<<COMPOUND>>" Test Script Creat __COMPOUND__.tst'.format(
                    File_name_upper, File_name))
        os.system('move __COMPOUND__.tst "{}"'.format(unit_tst_dir))
    else:
        pass


if __name__ == "__main__":
    File_name,File_name_upper = fun_for_taking_input()
    html_tst_dir, unit_tst_dir = fun_for_creating_folder_structure(File_name)
    fun_for_generating_reports(File_name,File_name_upper,html_tst_dir,unit_tst_dir)



