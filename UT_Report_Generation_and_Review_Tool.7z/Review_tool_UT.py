# Content #from Start_Program.py

##from Main import Review_for_UT



# Content #from Main.py
import os
##from Remove_Import_Faliures import remove_lines_between_keywor
#from Check_missing_html_reports import check_missing_html_reports
#from Enter_folder import Enter_Folder
#from Check_Reports import Check_html_reports
#from Test_notes_flow_missing import find_Test_notes_and_Test_flow
##from Checking_for_wrongly_placed_Unit_tst import check_wrongly_placed_unit
##from Unit_Tst_Checking import Check_Unit_Tsts
#from Find_serial_no_is_correct import find_serial_no_is_correct
#from Test_count_checking import count_test_items
##from Match_Unit_Tsts import Number_of_unit_tst_folder_matched
#from Function_name_import_faliure import Tst_name_with_import_faliure
#from Delete_Excel_Sheet import delete_excel_sheet
#from Find_missing_compound_only_tst import find_missing_compound_only_tst
#from Fun_for_checking_Import_faliures import fun_for_taking_import_faliurs
#from Cheking_Full_tst_unit_folder_is_present import Main_fun_for_checking_unit_tst_full_tst
##from Checking_for_wrongly_placed_full_tst import Full_tst_placed_wrongly
#from Fun_for_closing_excel import main_fun_for_closing_excel_file
##from Generate_Excel_sheet import Excel_sheet_funtion
#from Checking_path_of_directory import fun_for_checking_right_path
from colorama import init, Fore, Style
##from For_checking_pattern import main_function
##from Close_Excel_File import Close_Excel
# Function to count occurrences of TEST.NOTES, TEST.FLOW, and TEST.IMPORT_FAILURES in a file
init()
# Content #from Find_serial_no_is_correct.py

#from Generate_Excel_sheet import Excel_sheet_funtion
from colorama import init, Fore, Style
import os
init()
def check_series(lst):
    if len(lst) == 1 and lst[0] != '001':
        return False
    else:
        for i in range(len(lst) - 1):
            if int(lst[i]) + 1 != int(lst[i + 1]):
                return False
    return True
def made_dictoniary(local_file_path,var_name):
    Flag = False
    dictionary = {}
    for item in local_file_path:
        parts = item.split('.')
        key = parts[0]
        value = parts[1]
        if value.startswith('C'):
            value = value[1:]
            key = key+"_Compound_Testcase"
        if key not in dictionary:
            dictionary[key] = []
        dictionary[key].append(value)
    #print(dictionary)
    for key, value in dictionary.items():
        if key != 'UNCOVERD_PATH':
            if not check_series(value):
                print(Fore.RED+"Serial number of test cases is not correct for : "+Fore.RED+var_name+"/"+key)
                Excel_sheet_funtion(var_name+"/"+key,"Serial number of test cases is not correct")
        else:
            print(Fore.RED+Style.BRIGHT+"UNCOVERED_PATH is found for : "+ var_name)
            Excel_sheet_funtion(var_name, "UNCOVERED_PATH is found")
def find_serial_no_is_correct(local_file_path):
    Flag = "None"
    #Flage = "None"
    test_name_number_list = []
    var = os.path.basename(local_file_path)
    var = var.split(".")[0]
    with open(local_file_path, 'r') as file:
        for line in file:
                if line.startswith("TEST.NAME:"):
                    test_name = line.split(":")[-1].strip()
                    test_name_number_list.append(test_name)
        made_dictoniary(test_name_number_list,var)

# Content #from Check_missing_html_reports.py
import os
#from Generate_Excel_sheet import Excel_sheet_funtion
from colorama import init, Fore, Style
init()


def check_missing_html_reports(directory):
    Flag = False
    file_path = ""
    file_path_res_check_missing_html_reports = ""
    one_folder_back_local_n = os.path.dirname(directory)
    one_folder_back_local_m = os.path.dirname(one_folder_back_local_n)
    one_folder_back_res = os.path.basename(one_folder_back_local_m)
    file_path_res_check_missing_html_reports = one_folder_back_res.split("_VCAST")[0]
    
    lis_check_report_exist= []
    list_result = []
    lis_check_report_exist_reference = ['Execution','Testcase','Full']
    one_folder_back_local = os.path.dirname(directory)
    for filename in os.listdir(one_folder_back_local):
        if filename.startswith("Unit_Tst's"):
            continue
        if filename.endswith(".tst"):
            continue
        
        file_path = os.path.join(one_folder_back_local, filename)
        file_path = os.path.basename(file_path).strip()
        file_path = file_path.split('_')
        lis_check_report_exist.extend(file_path)
        #print(lis_check_report_exist)
    #print(lis_check_report_exist)
    #for sublist in lis_check_report_exist:
    for item in lis_check_report_exist_reference:
        if item not in lis_check_report_exist:
            list_result.append(item)
    for item in list_result:
        print(Fore.RED+Style.BRIGHT+item+"_Report is Missing for : "+file_path_res_check_missing_html_reports)
        Excel_sheet_funtion(file_path_res_check_missing_html_reports,item+"_Report is Missing")





def Review_for_UT():
    directory_path_Main_Entry = os.getcwd()

    flag_for_checking_right_path= fun_for_checking_right_path(directory_path_Main_Entry)
    if not flag_for_checking_right_path :
        print(Fore.RED+Style.BRIGHT+"Directory path provided is wrong")
        exit()

    main_fun_for_closing_excel_file(directory_path_Main_Entry)

    delete_excel_sheet(directory_path_Main_Entry)
    if not os.path.exists(directory_path_Main_Entry):
        print(Fore.RED+Style.BRIGHT+"Directory path does not exist")
        input(Style.BRIGHT+"Press Enter to continue...")
        exit()
    Main_fun_for_checking_unit_tst_full_tst(directory_path_Main_Entry)

    #Func_checking_Notes_written(directory_path)

    file_path_filename = Enter_Folder(directory_path_Main_Entry)
    Import_faliure_list = []
    Base_name =""
    one_folder_back =""
    for file_path, filename in file_path_filename:
        #print(file_path,filename)

        #input(Style.BRIGHT + "Press Enter to continue...")
        #count_subprogram = Check_unit_tst_matched(file_path)
        #count_subprogram_list.append(count_subprogram)
        Flag = False
        Filename_missed_count = []
        files_with_import_failures = []
        Test_Notes_Count, Test_Flow_Count, Import_Failures_Count, Compound_Unit_Tst_Count, Test_Slot_Count, Main_Compound_Tst = count_test_items(file_path)
        Total_compound_count = Main_Compound_Tst + Test_Slot_Count
        Total_tst_with_compound_count = Total_compound_count + Test_Flow_Count
            # Print counts
        print()
        light_orange = Fore.YELLOW + Fore.RED
        print(Fore.BLUE +Style.BRIGHT+"Counts for file:", light_orange + filename)
        print(Fore.GREEN+Style.BRIGHT+"TEST.NOTES:", Test_Notes_Count)
        print(Fore.GREEN+Style.BRIGHT+"TEST.FLOW:", Test_Flow_Count)
        print(Fore.GREEN+Style.BRIGHT+"TEST.IMPORT_FAILURES:", Import_Failures_Count)
        print(Fore.GREEN+Style.BRIGHT+"COMPOUND_UNIT_TST:", Compound_Unit_Tst_Count)
        print(Fore.GREEN+Style.BRIGHT+"COMPOUND_TST:", Main_Compound_Tst)
        print(Fore.GREEN+Style.BRIGHT+"TOTAL_COMPOUND_TST:", Total_compound_count)
        check_missing_html_reports(file_path)
        #if os.path.exists(file_path):
            #Full_tst_placed_wrongly(file_path, filename)
        #else:
            #print("Full tst is not present")

        #check_wrongly_placed_unit(file_path)
        filename_local = filename.split('.')[0]
        filename_local = filename_local.lower()
        #for item in list_of_programs_not_having_unit_tst_folder_local:
            #if item != filename_local:
                #Number_of_unit_tst_folder_matched(file_path,filename)
        find_serial_no_is_correct(file_path)
        #main_function(file_path)
        # Check for missing counts
        # Check for used Compound_Unit_Tst
        if Test_Slot_Count != Compound_Unit_Tst_Count:
            find_missing_compound_only_tst(file_path)
        find_Test_notes_and_Test_flow(file_path)
        back_folder_path = file_path
        given_path = back_folder_path
        one_folder_back = os.path.dirname(given_path)
        word1_to_search = "<<out-of-range>>"
        word2_to_search = "Number of Events has Exceeded Selected Limit"
        Check_html_reports(one_folder_back,word1_to_search, word2_to_search)
        # Check for import failures
        if Import_Failures_Count > 0:
                Tst_name_with_import_faliure(file_path)
                Flag = True
                Import_faliure_list.append(filename)

    fun_for_taking_import_faliurs(directory_path_Main_Entry,Import_faliure_list)
    input(Style.BRIGHT+"Press Enter to continue...")




# Content #from Enter_folder.py
import os
from colorama import init, Fore, Style
init()


def Enter_Folder(directory_path):
    res = ""
    global flag_for_checking_full_tst

# Validate directory path
    if not os.path.isdir(directory_path):
        print(Fore.RED+Style.BRIGHT+"Invalid directory path.")
        exit()
    for filename in os.listdir(directory_path):
        if filename.endswith("VCAST_UT_Results"):
            file_path = os.path.join(directory_path, filename)
            file_path = os.path.join(file_path, "Html&Tst's")
            for filename in os.listdir(file_path):
                if filename.endswith(".tst"):
                    file_path = os.path.join(file_path, filename)
                    yield file_path, filename
                    break







# Content #from Check_Reports.py
import os
import re
from bs4 import BeautifulSoup
#from Generate_Excel_sheet import Excel_sheet_funtion
#from Check_from_Unit_tst import check_from_unit_tst,dummy
#from Coverage_check import Find_full_coverage_in_reports,Find_Vector_cast_Specification_in_reports, Find_KLI_header_in_reports,Find_Environment_name_in_reports
from colorama import init, Fore, Style
init()
def Find_Out_of_range_in_reports(word1, html_file):
    with open(html_file, 'r', encoding='utf-8') as file:
        soup = BeautifulSoup(file, 'html.parser')
        # Get the filename #from the path
        filename = os.path.basename(html_file)
        # Check if the filename ends with ".html"
        if filename.endswith(".html"):
            if soup.find(string=lambda text: text and word1 in text):
                print(Fore.GREEN+f"Word '{word1}'" +Fore.RED+ "found in the HTML file:"+filename)
                Excel_sheet_funtion(filename, word1)




def Find_Exceeded_limit_in_reports(word2, html_file):
    with open(html_file, 'r', encoding='utf-8') as file:
        soup = BeautifulSoup(file, 'html.parser')
        # Get the filename #from the path
        filename = os.path.basename(html_file)
        # Check if the filename ends with ".html"
        if filename.endswith(".html"):
            if soup.find(string=lambda text: text and word2 in text):
                print(Fore.GREEN+f"Word '{word2}'" +Fore.RED+"found in the HTML file:" +filename)
                Excel_sheet_funtion(filename,word2)


def Check_html_reports(directory, word1, word2):
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        if filename.endswith(".html") and os.path.isfile(file_path):
            Find_Out_of_range_in_reports(word1, file_path)
            Find_Exceeded_limit_in_reports(word2, file_path)
            last_name = os.path.basename(file_path)
            last_name = last_name.split(".")[0]
            if not "Execution_Results_Report" in last_name:
                Find_full_coverage_in_reports(file_path)

            if not Find_KLI_header_in_reports(file_path):
                print(Fore.RED+Style.BRIGHT+"Header is not correct/present for : " + Fore.RED+last_name)
                Excel_sheet_funtion(last_name," Header is not correct/present")
            list_var = check_from_unit_tst(file_path)
            if list_var!= None:
                list_var = list_var.rstrip('\n').strip()
            if list_var == None:
                if not Find_Environment_name_in_reports(file_path):
                    print(Fore.RED + Style.BRIGHT+"Environment name is not correct for : " + Fore.RED+ last_name)
                    Excel_sheet_funtion(last_name, "Environment name is not correct")
            else:
                 var = dummy(file_path)
                 var = var.rstrip('\n').strip()
                 #print(list_var,var)
                 if var != list_var:
                    print(Fore.RED +Style.BRIGHT+ "Environment name is not correct for : " + Fore.RED + list_var)
                    Excel_sheet_funtion(list_var, "Environment name is not correct")

            if not Find_Vector_cast_Specification_in_reports(file_path):
                print(Fore.RED+"Vector_cast_version is not correct/present for: "+Fore.RED+ last_name)
                Excel_sheet_funtion(last_name, "Vector_cast_version is not correct/present")


# Content #from Test_notes_flow_missing.py
import openpyxl
from colorama import init, Fore, Style
import os
#from Generate_Excel_sheet import Excel_sheet_funtion
init()
def find_test_notes_between_subprograms(Data_Test_Notes):
    Flag = "None"
    Base_name = os.path.basename(Data_Test_Notes)
    Base_name = Base_name.split(".")[0]

    with open(Data_Test_Notes, 'r') as file:
        for line in file:
            if line.startswith("TEST.NAME:"):
                if Flag != "found_notes_TEST.NOTES_not_missing" and Flag != "None":
                    print(Fore.RED+Style.BRIGHT+Base_name+"/"+subprogram_name +Style.BRIGHT+Fore.RED +": TEST.NOTES_missing")
                    Excel_sheet_funtion(Base_name+"/"+subprogram_name,": TEST.NOTES_missing")
                subprogram_name = line.split(":")[-1].strip()
                Flag = "other_value"
            if line.startswith("TEST.NOTES"):
                Flag = "found_notes_TEST.NOTES_not_missing"


def find_test_flows_between_subprograms(Data_Test_Flow):
    Flag = "None"
    Base_name = os.path.basename(Data_Test_Flow)
    Base_name = Base_name.split(".")[0]
    with open(Data_Test_Flow, 'r') as file:
        for line in file:
            if line.startswith("TEST.COMPOUND_ONLY"):
                Flag = "compound_only"

            if line.startswith("TEST.NAME:"):
                if Flag != "found_notes_TEST.FLOW_not_missing" and Flag != "None" and Flag != "compound_only":
                    print(Fore.RED+Style.BRIGHT+Base_name+"/"+subprogram_name + Fore.RED+Style.BRIGHT+" : TEST.FLOW_missing")
                    Excel_sheet_funtion(Base_name+"/"+subprogram_name, ": TEST.FLOW_missing")
                subprogram_name = line.split(":")[-1].strip()
                Flag = "other_value"
            if line.startswith("TEST.FLOW"):
                Flag = "found_notes_TEST.FLOW_not_missing"

            if line.startswith("-- COMPOUND TESTS"):
                if Flag != "found_notes_TEST.FLOW_not_missing":
                    #print(subprogram_name + "\033[1;31m: TEST.FLOW_missing\033[0m")
                    break


def find_Test_notes_and_Test_flow(Data):

    find_test_notes_between_subprograms(Data)
    find_test_flows_between_subprograms(Data)



# Content #from Test_count_checking.py
import os

def count_test_items(file_path_dummy):
        Test_Notes_Count = 0
        Test_Flow_Count = 0
        Import_Failures_Count = 0
        Compound_Unit_Tst_Count  = 0
        Test_Slot_Count = 0
        Main_Compound_Tst = 0
        with open(file_path_dummy, 'r') as file:
            for line in file:
                line = line.strip()
                if line.startswith("TEST.NOTES"):
                    Test_Notes_Count += 1
                elif line.startswith("TEST.FLOW"):
                    Test_Flow_Count += 1
                elif line.startswith("TEST.IMPORT_FAILURES"):
                    Import_Failures_Count += 1
                elif line.startswith("TEST.COMPOUND_ONLY"):
                    Compound_Unit_Tst_Count += 1
                elif line.startswith("TEST.SLOT"):
                    Test_Slot_Count += 1
                elif line.startswith("-- COMPOUND TESTS"):
                    Main_Compound_Tst += 1

        return Test_Notes_Count, Test_Flow_Count, Import_Failures_Count, Compound_Unit_Tst_Count, Test_Slot_Count, Main_Compound_Tst




# Content #from Function_name_import_faliure.py
#from Generate_Excel_sheet import Excel_sheet_funtion
from colorama import init, Fore, Style
init()
def Tst_name_with_import_faliure(file_path):
    Flag = "None"
    file_name = ""
    #global user_input
    subprogram_name_list=[]
    file_path_local = os.path.dirname(file_path)
    file_path_local_updated = os.path.join(file_path_local, "Unit_Tst's")
    with open(file_path, 'r') as file:
        for line in file:
            if line.startswith("-- Unit:"):
                file_name = line.split(":")[-1].strip()

            if line.startswith("TEST.NAME:"):
                if Flag == "Import_faliure_found" and Flag != "None":
                    print( Fore.RED+Style.BRIGHT+"TEST.IMPORT_FAILURES found : "+ Fore.RED+file_name+"/"+subprogram_name )
                    Excel_sheet_funtion(file_name+"/"+subprogram_name,": TEST.IMPORT_FAILURES found")
                    subprogram_name_unit = subprogram_name.split(".")[0].strip()
                    file_path_local_updated=os.path.join(file_path_local, "Unit_Tst's")
                    file_path_local_updated_1=os.path.join(file_path_local_updated, subprogram_name_unit+".tst")
                    subprogram_name_list.append(file_path_local_updated_1)
                subprogram_name = line.split(":")[-1].strip()
                Flag = "other_value"
            if line.startswith("TEST.IMPORT_FAILURES:"):
                Flag = "Import_faliure_found"
        #user_input = input(Fore.BLUE + Style.BRIGHT + "Do you want to delete import errors from unit tst Y or N : ")
        #if user_input.upper() == "Y":
        for local_fun in subprogram_name_list:
                remove_lines_between_keywords(local_fun, "TEST.IMPORT_FAILURES:", "TEST.END_IMPORT_FAILURES:")

# Content #from Delete_Excel_Sheet.py
import os
def delete_excel_sheet(file_path):
    excel_sheet_path_xls = os.path.join(file_path, "Problem_sheet.xls")
    if os.path.exists(excel_sheet_path_xls):
        if excel_sheet_path_xls.lower().endswith('.xls'):
            os.remove(excel_sheet_path_xls)
           
    excel_sheet_path_xlsx = os.path.join(file_path, "Problem_sheet.xlsx")
    if os.path.exists(excel_sheet_path_xlsx):
        if excel_sheet_path_xlsx.lower().endswith('.xlsx'):
            os.remove(excel_sheet_path_xlsx)




# Content #from Find_missing_compound_only_tst.py
#from Generate_Excel_sheet import Excel_sheet_funtion
from colorama import init, Fore, Style
import os
init()
def find_missing_compound_only_tst(file_path_local):
    tstcase_name = ''
    test_name_compound_only =[]
    count=0
    Flag = False
    file_name = os.path.basename(file_path_local)
    filename_for_missing_compound_tst = file_name.split(".")[0]
    with open(file_path_local, 'r') as file:
        for line in file:
            if line.startswith("TEST.NAME:"):
                tstcase_name = line.split(":")[-1].strip()
            if line.startswith("TEST.COMPOUND_ONLY"):
               # print(tstcase_name)  it will print all tst name having TEST.COMPOUND_ONLY
                test_name_compound_only_name = '"'+tstcase_name+'"'
                test_name_compound_only.append(test_name_compound_only_name)
    Function_for_Test_slot_calculation(file_path_local,test_name_compound_only,filename_for_missing_compound_tst)



def Function_for_Test_slot_calculation(file_path_local,test_name_compound_only,filename_for_missing_compound_tst):
        Flag = False
        list_of_main_compound_tst =[]
        with open(file_path_local, 'r') as file:
            for line in file:
                if line.startswith("TEST.SLOT:"):
                    tst_name = line.split(",")[-1].strip()
                    list_of_main_compound_tst.append(tst_name)

        comparison_fun(test_name_compound_only,list_of_main_compound_tst,filename_for_missing_compound_tst)

def comparison_fun(test_name_compound_only,list_of_main_compound_tst,filename_for_missing_compound_tst):
    for item in test_name_compound_only:
        if not item in list_of_main_compound_tst:
            print(Fore.RED+Style.BRIGHT+"Compound unit tst is not used in Main Compound tst : ", filename_for_missing_compound_tst+"/"+item)
            Excel_sheet_funtion(filename_for_missing_compound_tst+"/"+item,"Compound unit tst is not used in Main Compound tst")



# Content #from Fun_for_checking_Import_faliures.py
#from Match_Unit_Tsts import Number_of_unit_tst_folder_matched
#from Remove_Import_Faliures import remove_lines_between_keywords
#from Enter_folder import Enter_Folder
#from Test_count_checking import count_test_items
import os
from colorama import init, Fore, Style
init()
Import_Failures_Count=0
user_input = ""
filename_fun = file_path_fun = ""

def fun_for_taking_import_faliurs(directory_path,Import_faliure_list):
    global Import_Failures_Count
   
    global filename_fun, file_path_fun
    file_path_filename = Enter_Folder(directory_path)
    import_faliures_count = []
    filepath_local= []
   
    for file_path_fun, filename_fun in file_path_filename:
        back_folder_path = file_path_fun
        given_path = back_folder_path
        # Get the parent directory
        one_folder_back = os.path.dirname(given_path)
        file_path_local = os.path.join(one_folder_back, "Unit_Tst's")
        if os.path.exists(file_path_local):
            Number_of_unit_tst_folder_matched(file_path_fun, filename_fun)
        Test_Notes_Count, Test_Flow_Count, Import_Failures_Count, Compound_Unit_Tst_Count, Test_Slot_Count, Main_Compound_Tst=count_test_items(file_path_fun)
        if Import_Failures_Count>0:
            import_faliures_count.append(Import_Failures_Count)
            filepath_local.append(file_path_fun)

    if import_faliures_count:
        user_input = input(Fore.BLUE + Style.BRIGHT + "Do you want to delete import errors Y or N : ")
        if user_input.upper() == "Y":
            for local_fun in filepath_local:
                remove_lines_between_keywords(local_fun, "TEST.IMPORT_FAILURES:", "TEST.END_IMPORT_FAILURES:")
                #print(local_fun)
            #for local_unit_tst_remove_import_error in var_for_unit_tst_import_error_removed_local:
                #remove_lines_between_keywords(local_unit_tst_remove_import_error, "TEST.IMPORT_FAILURES:", "TEST.END_IMPORT_FAILURES:")


# Content #from Cheking_Full_tst_unit_folder_is_present.py
import os
from colorama import init, Fore, Style
#from Generate_Excel_sheet import Excel_sheet_funtion
import sys
init()
Flag_Full_tst ="None"
Flag_for_Unit_tst_folder ="None"
def fun_for_checking_Unit_tst_folder_full_tst(directory):
    flag = False
    global Flag_Full_tst ,Flag_for_Unit_tst_folder
    Flag = False
    name = ""
    list=[]
    item = ""
    list_of_programs =[]
    list_unit_tst=[]
    list_full_tst=[]
    for filename in os.listdir(directory):

            if filename.endswith("VCAST_UT_Results"):
                name = filename.split("_VCAST")[0]
                file_path = os.path.join(directory, filename)
                file_path = os.path.join(file_path, "Html&Tst's")
                for filename in os.listdir(file_path):
                    if filename.endswith(".tst"):
                        Flag_Full_tst = "True"
                        break
                    else:
                        Flag_Full_tst = "False"
                if Flag_Full_tst =="False":
                    #print(Fore.RED+"Full tst is missing for : "+name)
                    list_full_tst.append(name)
                    Flag_Full_tst ="Flag_Full_tst"

                for filename in os.listdir(file_path):
                    if filename.startswith("Unit_Tst's") :
                        Flag_for_Unit_tst_folder = "True"
                        break
                    else:
                        Flag_for_Unit_tst_folder = "False"
                if Flag_for_Unit_tst_folder=="False":
                        #print(Fore.RED+Style.BRIGHT+"Unit tst folder is missing for : "+name)
                        list_unit_tst.append(name)
                        Flag_for_Unit_tst_folder = "Flag_for_Unit_tst_folder"

                if Flag_Full_tst == "Flag_Full_tst" and Flag_for_Unit_tst_folder == "Flag_for_Unit_tst_folder":
                    list_of_programs.append(name)
    if list_unit_tst:
        print(Fore.RED +Style.BRIGHT+"Following Files are not have Unit tst folder")
        for item in list_unit_tst:
            Excel_sheet_funtion(item, "Unit tst folder is missing")
            print(item)
            flag = True
    if list_full_tst:
        print(Fore.RED +Style.BRIGHT+"Following Files are not have Full tst")
        for item1 in list_full_tst:
            Excel_sheet_funtion(item1, "full tst is missing")
            print(item1)
            flag = True
    if list_of_programs:
        print(Fore.RED +Style.BRIGHT+ "Following Files are not have Unit tst folder and full tst : ")
    else:
        if flag:
            print(Style.BRIGHT + "Please add these and re run the tool")
            input(Style.BRIGHT + "Please exits #from the program" + sys.exit())
    for item in list_of_programs:
        print(item)
        Excel_sheet_funtion(item, "Unit tst folder and full tst both are missing")
    if list_of_programs or list_unit_tst or list_full_tst:
        print(Fore.BLUE+Style.BRIGHT+"Please correct it and re run the tool")
        input(Style.BRIGHT+"Please exits #from the program"+sys.exit())
    else:
        pass
def Unit_tst_is_wrongly_placed(directory):
    list_local = []
    list_res = {}
    flag = False
    flag_name = False
    #print(directory)
    for filename in os.listdir(directory):
            name_local = "None"
            if filename.endswith("VCAST_UT_Results"):
                name = filename.split("_VCAST")[0].strip()
                #print(name)
                file_path = os.path.join(directory, filename)
                file_path = os.path.join(file_path, "Html&Tst's")
                #print(file_path)
                for filename1 in os.listdir(file_path):
                    if filename1.endswith(".tst"):
                        filename_main = filename1.split(".")[0].strip()
                        if filename_main.upper() == name.upper():
                            file_path_local = os.path.join(file_path,filename1)
                            #print(file_path_local)
                            with open(file_path_local, 'r') as file:
                                for line in file:
                                    line = line.strip()
                                    if line.startswith("-- Subprogram:"):
                                        name_local = line.split(":")[-1].strip()
                                        list_local.append(name_local)
                                        #print(name_local)

                file_path_unit_tst = os.path.join(file_path, "Unit_Tst's")
                for unit_tst_folder in os.listdir(file_path_unit_tst):
                    if name_local =="None" and unit_tst_folder.endswith(".tst"):
                        print(Fore.RED+"Unit tst {} is placed wrongly for : ".format(unit_tst_folder)+name)
                        Excel_sheet_funtion(name + "/"+unit_tst_folder, "Unit tst is placed wrongly")
                    else:
                        if unit_tst_folder.endswith(".tst"):
                            if not unit_tst_folder.endswith("__COMPOUND__.tst"):
                                unit_tst_folder = unit_tst_folder.split(".")[0].strip()
                                #print(unit_tst_folder,name)
                                for unit_tst_full_tst in list_local:
                                    if unit_tst_folder.upper().strip() == unit_tst_full_tst.upper().strip():
                                        flag = False
                                        break
                                    else:
                                        flag = True
                                if flag:
                                    flag_name = True
                                    print(Fore.RED + "unit tsts {} are wrongly placed /missing for :".format(unit_tst_folder)+name)
                                    Excel_sheet_funtion(name + "/" + unit_tst_folder, "Unit tst is placed wrongly")
                            else:
                                pass
                        else:
                            print("Incorrect file : " + unit_tst_folder)
    return flag_name


def Full_tst_is_wrongly_placed(directory):
    filename_local_list = {}
    for filename in os.listdir(directory):
            if filename.endswith("VCAST_UT_Results"):
                name = filename.split("_VCAST")[0].strip()
                file_path = os.path.join(directory, filename)
                file_path = os.path.join(file_path, "Html&Tst's")
                for filename1 in os.listdir(file_path):
                    if filename1.endswith(".tst"):
                        filename_local = filename1.split(".")[0]
                        if filename_local.upper() != name.upper():
                            insert_value(filename_local_list, name, filename_local)
                        else:
                            pass


    return filename_local_list

def insert_value(dictionary, key, value):
    #print(key,value)
    if key not in dictionary:
        dictionary[key] = [value]  # Create a new list for the key if it doesn't exist
    else:
        # Check if the value is not already in the list to avoid duplicates
        if value not in dictionary[key]:
            dictionary[key].append(value)
    return dictionary
def Main_fun_for_checking_unit_tst_full_tst(directory):
    fun_for_checking_Unit_tst_folder_full_tst(directory)
    filename_local_list_full_tst = Full_tst_is_wrongly_placed(directory)
    flag_name = Unit_tst_is_wrongly_placed(directory)

    #print(filename_local_list_unit_tst)
    '''if filename_local_list_unit_tst:
        for key, value in filename_local_list_unit_tst.items():
                print(Fore.BLUE + "Following unit tsts are wrongly placed /missing for {} :".format(key))
                for item in value:
                    print(Fore.RED+item)
                    Excel_sheet_funtion(item,"Unit tst is wrongly placed/missing for {} :".format(key))'''
    if filename_local_list_full_tst:
        for key, value in filename_local_list_full_tst.items():
            print(Fore.BLUE+"Following Full tsts are wrongly placed /missing for {} :".format(key))
            for item in value:
                print(Fore.RED+item)
                Excel_sheet_funtion(item,"Full tst is wrongly placed/missing for {} :".format(key))
    if filename_local_list_full_tst or flag_name:
        print(Fore.BLUE+"Please correct it and re run the tool")
        exit()


# Content #from Fun_for_closing_excel.py
import psutil
import os
import subprocess
import time
from colorama import init, Fore, Style
init()


def is_excel_open(file_path):
    for process in psutil.process_iter():
        try:
            if "EXCEL.EXE" in process.name():
                for file in process.open_files():
                    if file_path.lower() == file.path.lower():
                        return True
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            pass
    return False


def close_excel(file_path):
    os.system('taskkill /f /im excel.exe')


def main_fun_for_closing_excel_file(file_path):
    file_path = file_path + "\\Problem_sheet.xlsx"
    if is_excel_open(file_path):
        print(Fore.RED +Style.BRIGHT+ "Your Excel sheet is open Please close it before proceeding." )
        input(Style.BRIGHT+"Press Enter to continue...")
        #close_excel(file_path)




# Content #from Checking_path_of_directory.py
import os


def fun_for_checking_right_path2(file_path):
    flag = False
    flag = os.path.exists(file_path)
    if flag:
        for filename_local in os.listdir(file_path):
            if filename_local.endswith('_VCAST_UT_Results'):
                return True

    return False
count_checking_path = 0
def fun_for_checking_right_path1(file_path):
    global count_checking_path
    flag = None
    invalid_characters = ['/', '\\', '/']  # List of invalid characters
    for char in invalid_characters:
        if char in file_path:
            flag = False
            if count_checking_path!=0:
                return fun_for_checking_right_path2(file_path)
    flag = False
    if not flag:
        count_checking_path += 1
        return os.path.exists(file_path)
def fun_for_checking_right_path(file_path):

        return fun_for_checking_right_path1(file_path)


# Content #from Generate_Excel_sheet.py
import openpyxl
import os
from colorama import init, Fore, Style
#from Checking_path_of_directory import fun_for_checking_right_path
init()
##from Remove_Import_Faliures import remove_lines_between_keywords
##from Close_Excel_File import Close_Excel
def create_excel_with_value(file_path, sheet_name, values_incoming,problem):
    # Create a new Excel workbook
    if os.path.exists(file_path):
        wb = openpyxl.load_workbook(file_path)
    else:
        wb = openpyxl.Workbook()

    # Select the active worksheet
    ws = wb.active
    ws.title = sheet_name
    next_row = ws.max_row + 1
    ws.cell(row=1, column=1, value="File_Name/Function_name/Tst_Name :")
    ws.cell(row=1, column=2, value="Problem")
    # Insert the value into the first column of the next available row
    ws.cell(row=next_row, column=1, value=values_incoming)
    ws.cell(row=next_row, column=2, value=problem)

    # Save the workbook
    wb.save(file_path)


def Excel_sheet_funtion(values_incoming,problem):
    global directory_path, input_taken,Excel_path
    sheet_name = "Problem_sheet"
    if not input_taken:
        Excel_path = os.path.join(directory_path + r"\Problem_sheet.xlsx")
        input_taken = True
    #print(Excel_path)
    create_excel_with_value(Excel_path, sheet_name, values_incoming, problem)



# Content #from Check_from_Unit_tst.py
import os
from bs4 import BeautifulSoup
def check_from_unit_tst(directory):
    Flag = False
    list_var= []
    back_folder_path = directory
    given_path = back_folder_path
    one_folder_back = os.path.dirname(given_path)
    for item in os.listdir(one_folder_back):
        if item.endswith('.tst'):
            return None
    if  Flag == False:
        path = os.path.join(one_folder_back, "Unit_Tst's")
        for item in os.listdir(path):
            if item.endswith('.tst'):
                file_path = os.path.join(path, item)
                with open(file_path, 'r') as file:
                    for line in file:
                        if line.startswith('-- Environment'):
                            var = line.split(':')[-1]
                            list_var.append(var)
    return list_var[0]

def dummy(html_file):
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        env_name_row = soup.find('th', string='Environment Name').find_next_sibling('td')
        environment_name = env_name_row.text.strip()
        return environment_name







# Content #from Coverage_check.py
from bs4 import BeautifulSoup
import os
#from Generate_Excel_sheet import Excel_sheet_funtion
from colorama import init, Fore, Style
init()
def Find_Statement_Coverage_in_reports(html_file):
    flag = False
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        td_element = soup.find('td', id='overall-results-statements')
        if td_element != None:
            td_text = td_element.get_text().strip()
            if td_text == "No Coverage Results Exist":
                flag = True
                return flag
            else:
                last_part = td_text.split("(")[-1]  # Get the last part of the text
                if last_part == "100%)":
                    flag = True
                    return flag
        else:
            flag = True

    return flag


def Find_Branch_Coverage_in_reports(html_file):
    flag = False
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        td_element = soup.find('td', id='overall-results-branches')
        if td_element != None:
            td_text = td_element.get_text().strip()
            if td_text == "No Coverage Results Exist":
                flag = True
                return flag
            else:
                last_part = td_text.split("(")[-1]  # Get the last part of the text
                if last_part == "100%)":
                    flag = True
                    return flag
        else:
            flag = True
    return flag


def Find_Pairs_Coverage_in_reports(html_file):
    flag = False
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        td_element = soup.find('td', id='overall-results-mcdc-pairs')
        if td_element != None:
            td_text = td_element.get_text().strip()
            if td_text == "No pairs exist":
                flag = True
                return flag
            else:
                last_part = td_text.split("(")[-1]  # Get the last part of the text
                if last_part == "100%)":
                    flag = True
                    return flag
        else:
            flag = True
    return flag
def Find_Testcases_Pass_in_reports(html_file):
    flag = False
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        td_element = soup.find('td', id='overall-results-testcases')
        if td_element != None:
            td_text = td_element.get_text()

            if td_text == "No Execution Results Exist":
                flag = True
                return flag
            else:
                last_part = td_text.split(" ")[-1]  # Get the last part of the text
                if last_part == "PASS":
                    flag = True
                    return flag
                elif last_part == "FAIL":
                    return flag
        else:
            return flag
def Find_Expecteds_Pass_in_reports(html_file):
    flag = False
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        td_element = soup.find('td', id='overall-results-expecteds')
        if td_element != None:
            td_text = td_element.get_text().strip()
            #print(td_text)
            if td_text == "No Execution Results Exist":
                flag = True
                return flag
            else:
                last_part = td_text.split(" ")[-1]  # Get the last part of the text
                if last_part == "PASS":
                    flag = True
                    return flag
                elif last_part == "FAIL":
                    return flag
        else:
            return flag

def Find_Control_Flow_Pass_in_reports(html_file):
    flag = False
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        td_element = soup.find('td', id='overall-results-control-flows')
        if td_element != None:
            td_text = td_element.get_text()
            if td_text == "No Execution Results Exist":
                flag = True
                return flag
            else:
                last_part = td_text.split(" ")[-1]  # Get the last part of the text
                if last_part == "PASS":
                    flag = True
                    return flag
                elif last_part == "FAIL":
                    return flag
        else:
            flag = True
            return flag

def Find_KLI_header_in_reports(html_file):
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        td_element = soup.find('div', id='report-title')
        if td_element!=None:
            td_text = td_element.get_text().strip()
            if "ITC" in td_text:
                return True
        else:
            return True
    return False

def Find_Vector_cast_Specification_in_reports(html_file):
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        env_name_th = soup.find('th', string='VectorCAST Version')
        if env_name_th is None:
            return False  # Element not found, specification not found
        env_name_td = env_name_th.find_next_sibling('td')
        if env_name_td is None:
            return False  # Sibling not found, specification not found
        environment_name = env_name_td.text.split("(")[0].strip()
        if environment_name == "21.sp8":
            return True  # Specification found
    return False


def Find_Environment_name_in_reports(html_file):
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        env_name_row = soup.find('th', string='Environment Name').find_next_sibling('td')
        environment_name = env_name_row.text.strip()
        back_folder_path = html_file
        given_path = back_folder_path
        one_folder_back = os.path.dirname(given_path)
        for filename in os.listdir(one_folder_back):
            if filename.endswith(".tst"):
                file_path = os.path.join(one_folder_back, filename)
                with open(file_path, 'r') as file:
                    for line in file:
                        if line.startswith("-- Environment"):
                            var = line.split(':')[-1].strip()
                            if var == environment_name:
                                return True



    return False



def Find_full_coverage_in_reports(html_file_path):

    last_name = os.path.basename(html_file_path)
    Problem_report_name = last_name.split(".")[0]
    if not Find_Statement_Coverage_in_reports(html_file_path):
        print(Fore.RED+Style.BRIGHT+"Statement Coverage is not  100% for  : " +Fore.RED+ Problem_report_name)
        Excel_sheet_funtion(Problem_report_name,"Statement Coverage is not  100%")
    if not Find_Branch_Coverage_in_reports(html_file_path):
        print(Fore.RED+Style.BRIGHT+"Branch Coverage is not  100% for : " + Fore.RED+ Problem_report_name)
        Excel_sheet_funtion(Problem_report_name, "Branch Coverage is not  100%")
    if not Find_Pairs_Coverage_in_reports(html_file_path):
        print(Fore.RED+Style.BRIGHT+"MCDC Pairs Coverage is not  100% for : " + Fore.RED+ Problem_report_name)
        Excel_sheet_funtion(Problem_report_name, "MCDC Pairs Coverage is not  100%")
    decision_Testcases = Find_Testcases_Pass_in_reports(html_file_path)
    if decision_Testcases:
        print()
    else:
        print(Fore.RED +Style.BRIGHT+ Problem_report_name +"_Testcases is : FAIL " )
        Excel_sheet_funtion(Problem_report_name,"Testcases : FAIL")
    decision_Expecteds = Find_Expecteds_Pass_in_reports(html_file_path)
    if decision_Expecteds:
        print()
    else:
        print(Fore.RED +Style.BRIGHT+Problem_report_name + "_Expected is : FAIL")
        #print(Problem_report_name)
        Excel_sheet_funtion(Problem_report_name, "Expecteds : FAIL")
    decision_Control_flow = Find_Control_Flow_Pass_in_reports(html_file_path)
    if decision_Control_flow:
        print()
    else:

        print(Fore.RED + Style.BRIGHT+Problem_report_name+"_Control_Flow is : FAIL")
        Excel_sheet_funtion(Problem_report_name, "_Control_Flow : FAIL")





# Content #from Remove_Import_Faliures.py

def remove_lines_between_keywords(file_path, start_keyword, end_keyword):
    # Read all lines #from the file
    with open(file_path, 'r') as file:
        lines = file.readlines()

    # Flag to indicate whether to keep lines or not
    keep_lines = True
    new_lines = []

    # Iterate through each line
    for line in lines:
        # Check if the line starts with the start keyword
        if line.startswith(start_keyword):
            # Set flag to False to start removing lines
            keep_lines = False
        # Check if the line starts with the end keyword
        elif line.startswith(end_keyword):
            # Set flag to True to stop removing lines
            keep_lines = True
        # Check if the flag is True, meaning we should keep the line
        elif keep_lines:
            # Append the line to the new lines list
            new_lines.append(line)

    # Write the new lines back to the file
    with open(file_path, 'w') as file:
        file.writelines(new_lines)


# Content #from Match_Unit_Tsts.py
import os
#from Generate_Excel_sheet import Excel_sheet_funtion
#from Test_count_checking import count_test_items
from colorama import init, Fore, Style
init()
def Subprogram_count(file_path):
    subprogram_name =[]
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line.startswith("-- Subprogram:"):
                name = line.split(':')[-1].strip()
                subprogram_name.append(name)
    return subprogram_name

def Unit_Tst_count(file_path):
    Flag = False
    unit_tst_name_list=[]
    one_folder_back = os.path.dirname(file_path)
    file_path_local = os.path.join(one_folder_back, "Unit_Tst's")
    for filename in os.listdir(file_path_local):
        if filename != "__COMPOUND__.tst":
            if filename.endswith(".tst"):
                unit_tst_name = filename.split('.')[0]
                unit_tst_name_list.append(unit_tst_name)

    return unit_tst_name_list
def fun_for_checking_compound_tst_missing(file_path_local,file_path_local_name):
    Flag = False
    local_name = file_path_local_name.split('.')[0]
    one_folder_back = os.path.dirname(file_path_local)
    file_path_local = os.path.join(one_folder_back, "Unit_Tst's")
    for filename in os.listdir(file_path_local):
        if filename == "__COMPOUND__.tst":
            Flag = True
            break

    return Flag,local_name



def name_matching(subprogram_name_local_list, unit_tst_name_local_list, filename_without_extension):
    ORANGE = Fore.YELLOW + Fore.RED
    Flage =False
    for item_sub in subprogram_name_local_list:
        if item_sub not in unit_tst_name_local_list:
            print(ORANGE + Style.BRIGHT +filename_without_extension+":"+item_sub + Fore.RED + Style.BRIGHT + ": Unit tst is missing")
            Excel_sheet_funtion(filename_without_extension +" : " +item_sub,"Unit Tst is missing")

def fun_for_checking_contained_compound(file_path):
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line.startswith("-- COMPOUND TESTS"):
                return True
    return False
def Number_of_unit_tst_folder_matched(file_path, filename):
    if fun_for_checking_contained_compound(file_path):
        flag_local, name_local = fun_for_checking_compound_tst_missing(file_path,filename)
        if not flag_local:
            print(Fore.GREEN + Style.BRIGHT + name_local + Fore.RED + " :Compound tst missing")
            Excel_sheet_funtion(name_local, "Compound tst missing")
    subprogram_name = Subprogram_count(file_path)
    unit_tst_name = Unit_Tst_count(file_path)
    filename_without_extension = os.path.basename(file_path)
    filename_without_extension = filename_without_extension.split('.')[0]
    name_matching(subprogram_name,unit_tst_name,filename_without_extension)


Excel_path = None
input_taken = False
directory_path = os.getcwd()
flag_for_checking_right_path1= fun_for_checking_right_path(directory_path)
if not flag_for_checking_right_path1:
    print(Fore.RED+Style.BRIGHT+"Directory path provided is wrong")
    exit()


        
if __name__ == "__main__":
    Review_for_UT()
    