import os
import shutil
import re
from bs4 import BeautifulSoup
import openpyxl
from openpyxl.styles import Font
from colorama import init, Fore, Style
import psutil

init()

def Environment_variable_setting():
    var_project_name = input(Fore.GREEN + Style.BRIGHT + "Project name is DCU (Y/N): ")
    print(Style.RESET_ALL)
    if var_project_name.upper() == "Y":
        os.environ["Environment_Name_for_file"] = "DCU"
        os.system(
            r'C:\VCAST\clicast.exe -lc -e {}  TESt Delete yes'.format(os.environ["Environment_Name_for_file"]))
    else:
        Environment_Name = input("Enter the Project Name : ")
        os.environ["Environment_Name_for_file"] = Environment_Name
    print(Fore.GREEN + Style.BRIGHT + "All previous imported Test cases are deleted")
    print(Style.RESET_ALL)
    var_unit_name = input(Fore.GREEN + Style.BRIGHT + "Unit name is CtApASW_FailSafe (Y/N) : ")
    print(Style.RESET_ALL)
    if var_unit_name.upper() == "Y":
        os.environ["Unit_Name"] = "CtApASW_FailSafe"
    else:
        Unit_Name = input("Enter the Unit Name : ")
        os.environ["Unit_Name"] = Unit_Name



def Create_Excel_For_Number_of_Testcases(Total_Number_of_Testcases, Passed_Number_of_Testcases, Failed_Number_of_Testcases):
    file_path = os.getcwd()
    file_path = os.path.join(file_path, "Count_of_Testcases.xlsx")

    # Check if the file exists
    if os.path.exists(file_path):
        wb = openpyxl.load_workbook(file_path)
    else:
        wb = openpyxl.Workbook()

    # Select the active worksheet
    ws = wb.active
    ws.title = "Number_of_Testcases"
    next_row = ws.max_row + 1

    # Write the header only if the file is newly created
    ws.cell(row=1, column=1, value="Total_Testcases")
    ws.cell(row=1, column=2, value="Passed_Testcases")
    ws.cell(row=1, column=3, value="Failed_Testcases")
    bold_font = Font(bold=True)
    ws.cell(row=1, column=1).font = bold_font
    ws.cell(row=1, column=2).font = bold_font
    ws.cell(row=1, column=3).font = bold_font
    ws.cell(row=1, column=4).font = bold_font
    ws.cell(row=next_row, column=1, value=Total_Number_of_Testcases)
    ws.cell(row=next_row, column=2, value=Passed_Number_of_Testcases)
    ws.cell(row=next_row, column=3, value=Failed_Number_of_Testcases)

    # Save the workbook
    wb.save(file_path)

def Count_Testcases(Reports_Name_local):
    #flag = False
    Current_directory = os.getcwd()
    main_path = os.path.join(Current_directory, Reports_Name_local)
    Total_Number_of_Testcases_array = []
    Total_Number_of_Failed_Testcases_array = []
    Total_Number_of_Passsed_Testcase_array = []
     
    with open(main_path, 'r', encoding='utf-8') as file:
        html_content = file.read()
        soup = BeautifulSoup(html_content, 'html.parser')
        td_element = soup.find('td', id='overall-results-testcases')
        if td_element != None:
            td_text = td_element.get_text()

            if td_text == "No Execution Results Exist":
                pass
            else:
                Test_cases = td_text.split(" ")[-1]  # Get the last part of the text
                if Test_cases == "PASS":
                    Total_testcase_present = td_text.split("/")[-1]
                    Total_testcase = Total_testcase_present.split(" ")[1].strip()
                    Total_testcase_int = int(Total_testcase)
                    Total_Number_of_Testcases_array.append(Total_testcase_int)
                    Total_Number_of_Passsed_Testcase_array.append(Total_testcase_int)
                else:
                    Total_testcase_present = td_text.split("/")[-1]
                    Total_testcase = Total_testcase_present.split(" ")[1].strip()
                    Passed_testcase_with_FAIL = td_text.split("/")[0].strip()
                    Total_testcase_int = int(Total_testcase)
                    Passed_testcase_int = int(Passed_testcase_with_FAIL)
                    Failed_testcases = Total_testcase_int - Passed_testcase_int
                    Total_Number_of_Failed_Testcases_array.append(Failed_testcases)
                    Total_Number_of_Passsed_Testcase_array.append(Passed_testcase_int)
                    Total_Number_of_Testcases_array.append(Total_testcase_int)
                    
                   
        else:
            pass

   
    return Total_Number_of_Failed_Testcases_array,Total_Number_of_Testcases_array,Total_Number_of_Passsed_Testcase_array

def Count_Number_of_Testcases(Reports_Name_local):
    global Sum_Failed_Testcases, Sum_Total_Testcases, Sum_Passed_Testcases
    Current_directory = os.getcwd()
    main_path = os.path.join(Current_directory, Reports_Name_local + ".html")
    
    # Get the current counts from the file
    Failed_Testcases, Total_Testcases, Passed_Testcases = Count_Testcases(main_path)
    
    # Add the current counts to the global totals
    Sum_Failed_Testcases += sum(Failed_Testcases)
    Sum_Total_Testcases += sum(Total_Testcases)
    Sum_Passed_Testcases += sum(Passed_Testcases)
    return Sum_Failed_Testcases,Sum_Total_Testcases,Sum_Passed_Testcases

def Move_Html_Report(Reports_Name_local_html, folder_path_for_report_move_local_html):
    current_directory = os.getcwd()
    Source_Path_html = os.path.join(current_directory, Reports_Name_local_html + ".html")
    Destination_Path = os.path.join(current_directory, folder_path_for_report_move_local_html)
    shutil.move(Source_Path_html, Destination_Path)


def Move_Tst_Report(Reports_Name_local_tst, folder_path_for_report_move_local_tst):
    current_directory = os.getcwd()
    Source_Path_tst = os.path.join(current_directory, Reports_Name_local_tst + ".tst")
    Destination_Path = os.path.join(current_directory, folder_path_for_report_move_local_tst)
    shutil.move(Source_Path_tst, Destination_Path)


def Reports_Folder_Name_Generation(path):
    Requirement_Report_Name = os.path.basename(path)
    Requirement_Report_Name1 = Requirement_Report_Name.split('.')[0].strip()
    return Requirement_Report_Name1


def create_excel_with_value(File_Name, Requirement_Name, Requirement_Testcase_Name):
    file_path = os.getcwd()
    file_path = os.path.join(file_path, "Failed_testcase.xlsx")

    # Check if the file exists
    if os.path.exists(file_path):
        wb = openpyxl.load_workbook(file_path)
    else:
        wb = openpyxl.Workbook()

    # Select the active worksheet
    ws = wb.active
    ws.title = "Failed_Testcases"
    next_row = ws.max_row + 1

    # Write the header only if the file is newly created
    ws.cell(row=1, column=1, value="File_Name")
    ws.cell(row=1, column=2, value="Requirement_Name")
    ws.cell(row=1, column=3, value="Requirement_Testcase_Name")
    ws.cell(row=1, column=4, value="Status")
    bold_font = Font(bold=True)
    ws.cell(row=1, column=1).font = bold_font
    ws.cell(row=1, column=2).font = bold_font
    ws.cell(row=1, column=3).font = bold_font
    ws.cell(row=1, column=4).font = bold_font
    ws.cell(row=next_row, column=1, value=File_Name)
    ws.cell(row=next_row, column=2, value=Requirement_Name)
    ws.cell(row=next_row, column=3, value=Requirement_Testcase_Name)
    ws.cell(row=next_row, column=4, value="FAIL")

    # Save the workbook
    wb.save(file_path)


def Failed_Testcase_Found(Reports_Name_local, Requirement_Name, Requirement_Name_folder_Name):
    Current_directory = os.getcwd()
    main_path = os.path.join(Current_directory, Reports_Name_local + ".html")
    with open(main_path, 'r', encoding='utf-8') as file:
        html_content = file.read()

    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(html_content, 'html.parser')

    # Find all 'li' elements with class names starting with 'tc-item'
    elements = soup.find_all('li', class_=re.compile(r'^tc-item'))

    # Check for 'tc-passed' in the class list and print the title attribute if found
    for element in elements:
        if 'tc-failed' in element.get('class', []):
            variable = element['title']
            create_excel_with_value(Requirement_Name_folder_Name, Requirement_Name, variable)


def Commands_For_Execution_And_Report_Generation(Path_of_tsts_local, folder_path_for_report_move_local, count_folder):
    count_done_requirement = 0
    for tst_path_requirements, folder_path_move_tst in zip(Path_of_tsts_local, folder_path_for_report_move_local):
        Reports_Name = Reports_Folder_Name_Generation(tst_path_requirements)
        os.system(
            r'C:\VCAST\clicast.exe -lc -e {} TESt Script Run {}'.format(os.environ["Environment_Name_for_file"],
                                                                             tst_path_requirements))
        os.system(r'C:\VCAST\clicast.exe -lc -e {} EXecute Batch [--update_coverage_data]'.format(
            os.environ["Environment_Name_for_file"]))
        os.system(r'C:\VCAST\clicast.exe -lc -e {} Reports Custom Full {}.html'.format(
            os.environ["Environment_Name_for_file"], Reports_Name))
        Sum_Failed_Testcases,Sum_Total_Testcases,Sum_Passed_Testcases=Count_Number_of_Testcases(Reports_Name)
        Requirement_Name_path = os.path.dirname(tst_path_requirements)
        Requirement_Name = os.path.basename(Requirement_Name_path)
        Requirement_Name_folder_path = os.path.dirname(Requirement_Name_path)
        Requirement_Name_folder_Name = os.path.basename(Requirement_Name_folder_path)
        Failed_Testcase_Found(Reports_Name, Requirement_Name, Requirement_Name_folder_Name)
        Move_Html_Report(Reports_Name, folder_path_move_tst)
        os.system(r'C:\VCAST\clicast.exe -lc -e {}  TEST Script Create {}.tst'.format(
            os.environ["Environment_Name_for_file"], Reports_Name))
        count_done_requirement = count_done_requirement + 1
        print(Fore.GREEN + Style.BRIGHT + "Total_Requirement_Number : ", count_folder, "/",
              "Completed_Requirement_Number : ", count_done_requirement)
        print(Style.RESET_ALL)
        Move_Tst_Report(Reports_Name, folder_path_move_tst)
        os.system(
            r'C:\VCAST\clicast.exe -lc -e {} TESt Delete yes'.format(os.environ["Environment_Name_for_file"]))
    print(Fore.GREEN + Style.BRIGHT + "Failed_Testcses: "+ str(Sum_Failed_Testcases),"Total_Testcases: "+ str(Sum_Total_Testcases),"Passed_Testcases: "+str(Sum_Passed_Testcases))
    Create_Excel_For_Number_of_Testcases(Sum_Total_Testcases, Sum_Passed_Testcases, Sum_Failed_Testcases)
    print(Style.RESET_ALL)


def Sending_tst_path():
    count_folder = 0
    Tst_path = input(Fore.GREEN + Style.BRIGHT + "Enter the path of Testcases : ")
    print(Style.RESET_ALL)
    Path_Array = []
    folder_path_report_move = []
    for root, dirs, files in os.walk(Tst_path):
        for file in files:
            if file.endswith('.tst'):
                count_folder = count_folder + 1
                file_path = os.path.join(root, file)
                Path_Array.append(file_path)
                target_dir = os.path.relpath(root, Tst_path)
                folder_path = os.path.join("Tsts_Report", target_dir)
                folder_path_report_move.append(folder_path)
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path)
    return Path_Array, folder_path_report_move, count_folder


def is_excel_open(file_path):
    for process in psutil.process_iter():
        try:
            if "EXCEL.EXE" in process.name():
                for file in process.open_files():
                    if file_path.lower() == file.path.lower():
                        return True
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            pass
    return False


def close_excel(file_path):
    os.system('taskkill /f /im excel.exe')


def main_fun_for_closing_excel_file():
    current_directory = os.getcwd()
    file_path_Failed_Testcase = current_directory + "\\Failed_testcase.xlsx"
    file_path_Count_Testcase = current_directory + "\\Count_of_Testcases.xlsx"
    if is_excel_open(file_path_Failed_Testcase):
        close_excel(file_path_Failed_Testcase)
    if is_excel_open(file_path_Count_Testcase):
        close_excel(file_path_Count_Testcase)

def To_Delete_Excel_sheet_xlsx_formate():
    file_names = ["Failed_testcase.xlsx", "Count_of_Testcases.xlsx"]

    for file_name in file_names:
        if os.path.exists(file_name):
           os.remove(file_name)
        else:
           pass

def To_Delete_Excel_sheet_xls_formate():
    file_names = ["Failed_testcase.xls", "Count_of_Testcases.xls"]

    for file_name in file_names:
        if os.path.exists(file_name):
            os.remove(file_name)
    else:
        pass


if __name__ == "__main__":
    Sum_Failed_Testcases = 0 
    Sum_Total_Testcases = 0 
    Sum_Passed_Testcases = 0
    folder_name = 'Tsts_Report'
    main_fun_for_closing_excel_file()
    To_Delete_Excel_sheet_xlsx_formate()
    To_Delete_Excel_sheet_xls_formate()
    # Check if the folder exists and delete it
    if os.path.exists(folder_name) and os.path.isdir(folder_name):
        shutil.rmtree(folder_name)
    else:
        pass

    Environment_variable_setting()
    Path_of_tsts, folder_path_for_report_move, count_folder = Sending_tst_path()
    Commands_For_Execution_And_Report_Generation(Path_of_tsts, folder_path_for_report_move, count_folder)
